<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>HOTEL NS</title>
    <link rel="stylesheet" href="hotel.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
</head>
<body>
    


    <!---navbar-->

    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
          <h1 style="color: #29f700;">HOTEL NS</h1><font style="font-size: 30px;color: white;margin-right: 200px;font-family:sans-serif;">Welcome to Hotel NS</font>
          </div>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link" href="#home">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#home">About</a>
              </li>
             
              <li class="nav-item">
                <a class="nav-link" href="#home">Contact</a>
              </li>
             </ul>
                
          </div>
    </nav>
        
    <div class="head">
    <h1>PRODUCT LIST</h1>
    </div><br><br><br>
    <?php $connect=mysqli_connect("Localhost","root","","hotel"); 
        $q="select * from addto";
        $rowcount=0;
        $s=$connect->query($q);
    ?>
    <label></label>
    <form method="post">
        <table class="user-detail">
        <tr>
            <td>Name</td>
            <td><input type="text" name="uname" placeholder="Enter your name" required></td>
        </tr>
        <tr>
            <td>Phone Number</td>
            <td><input type="text" name="phone" placeholder="Enter your Phone Number" pattern="[0-9]+" maxlength="10" required></td>
        </tr>
    </table>
<br><br><br>
    <style>
        .product-detail,.one,.two,.three
        {
            border: 1px solid black;
        }
    </style>
    <table class="product-detail" >
        <tr class="one">
            <th class="two">ID</th>
            <th class="two">NAME</th>
            <th class="two">PRICE</th>
            <th class="two">QUANTITY</th>
            <th class="two">TOTAL PRICE</th>
        </tr>
        <?php
        $total=0;
        foreach($s as $m)
        { ?>
        <tr>
            <td class="three"><?php echo $id=$m['sno']; ?></td>
            <td class="three"><?php echo $toyname=$m['item']; ?></td>
            <td class="three" id="price"><i class='fa-sharp fa-solid fa-indian-rupee-sign'></i><?php echo $price=$m['price']; ?></td>
            <td class="three"><?php echo $m['quantity']; ?></td>
            <td class="three"><?php echo $m['tprice'] ?></td>
        </tr>
        <?php
        }
        ?>
        
        </table>
        <br><br>
        <label class="total" id="total">Total price : </label><div class="tot"><i class='fa-sharp fa-solid fa-indian-rupee-sign'></i><span id="tot">
        <?php 
            $amount=0;
            $quantity=0;
            $m="select tprice,quantity from addto"; 
            $n=$connect->query($m);
            foreach($n as $val)
            {
                $amount+=$val['tprice'];
                $quantity+=$val['quantity'];
            }
            echo $amount;
        ?>
         </span></div><br><br><br>
        <button class="buy" type="submit" name="buy"><i class="fa-solid fa-cart-shopping"></i> Buy</button>
        <br><br><br>
        
        <?php 
        if(isset($_POST['buy']))
        {
            $id=0;
            $uname=$_POST['uname'];
            $phone=$_POST['phone'];
            $query="insert into buy values('$id','$uname','$phone','$quantity','$amount')";
            $connect->query($query);

            $qu="select sno,quantity from addto";
            $rows=$connect->query($qu);
            foreach($rows as $val)
            {
                $que="update addto set quantity=quantity-'$val[quantity]' where sno='$val[sno]'";
                $connect->query($que);
            }

            $query1="delete from addto";
            $connect->query($query1);

            echo "<script>alert('Thankyou for Buying!')</script>";

        }
        ?>

        </form>