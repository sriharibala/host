<?php
if(isset($_POST['s3']))
{
$a=$_POST['t1'];
$con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
$r="select * from user where mail='".$a."'";
$res = $con->query($r);
$num = mysqli_num_rows($res);
if($num == 1 )
{
 header("location:hotel.html");
}
else
{
echo "Failed to register";
}
}
?>