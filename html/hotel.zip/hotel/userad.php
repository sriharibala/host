<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="newadmin.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
</head>
<body>
    <div class="head">
        <h1>ADMIN</h1>
    </div>

    <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="add.php"><i class="fa-solid fa-plus"></i> Addnew</a>
        <a href="uesrad.php"><i class="fa-solid fa-users"></i>User Details</a>
        <a href="contad.php"><i class="fa-solid fa-gear"></i> CONTACTUS</a>
    </div>

<body>
    <div class="add" style="margin-top: -500px;margin-left: 600px;">
    <h1 style="margin-left:-300px;margin-top: 10px;color : blue">USER DETAILS</h1><br>
<?php
        $con=mysqli_connect("localhost","root","","hotel");
        if(!$con)
        {
            echo "not connected";
        }
        $q="SELECT * FROM user";
        $view=$con->query($q);
        foreach($view as $value)
        {
            ?>
                <div class="ca" style="display:inline-flex; margin-left: -30px;">     
               <table style="margin-left:100px;">		
               <tr>
               <th>NAME</th>
               <th>MAIL</th>
               <th>PASS</th>
        </tr>
        <tr>
                   <td><?php echo $value['name'];?>&nbsp;&nbsp;&nbsp;</td>
                    <td><?php echo $value['mail'];?>&nbsp;&nbsp;&nbsp;</td>
					<td> <?php echo $value['pass'];?>&nbsp;&nbsp;&nbsp;</td></tr>
					 </table>
                </div>
				

      <?php  } ?>
	  </body>
	  </html>