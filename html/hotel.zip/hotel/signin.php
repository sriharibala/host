<?php
if(isset($_POST['s3']))
{
    $a=$_POST['t1'];
    $b=$_POST['t2'];
    $c=$_POST['t3'];
    $id=0;
    $con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
$d="insert into user  values('$id','$a','$b','$c')";
$d1=$con->query($d);
if($d1==TRUE)
{
 header("location:hotel.html");
}
else
{
echo "Failed to login";
}
}
?>