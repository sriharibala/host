<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="newadmin.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
</head>
<body>
    <div class="head">
        <h1>ADMIN</h1>
    </div>

    <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="add.php"><i class="fa-solid fa-plus"></i> Addnew</a>
        <a href="userad.php"><i class="fa-solid fa-users"></i>User Details</a>
        <a href="contad.php"><i class="fa-solid fa-gear"></i> CONTACTUS</a>
    </div>

    <div class="dash">
        <div class="dash1" style="margin-left:10px;">
            <img src="img26.jpg" style="margin-right:50px;margin-left: 25px;margin-top: 10px;border-radius: 100%;border-color: black;">
            <p>Total Stock</p>
            <span id="stock">0</span>
        </div>
        <div class="dash2" style="margin-left:50px;">
        <img src="img27.jpg" style="margin-right:50px;margin-left: 25px;margin-top: 10px;border-radius: 100%;border-color: black;"><br>
            <p>Number of Sales</p>
            <span id="sales">0</span>
        </div>
        <div class="dash3">
        <img src="img28.jpg" style="margin-right:50px;margin-left: 25px;margin-top: 10px;border-radius: 100%;border-color: black;"><br>
            <p>Happy Users</p><br>
            <span id="happyuser">0</span>
        </div>
    </div>
</body>
</html>