<?php
session_start();
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>HOTEL NS</title>
    <link rel="stylesheet" href="hotel.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
</head>
<body>
    


    <!---navbar-->

    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
          <h1 style="color: #29f700;">HOTEL NS</h1><font style="font-size: 30px;color: white;margin-right: 400px;font-family:sans-serif;">Welcome to Hotel NS</font>
          </div>
    </nav>
    <img style="margin-left: 500px;margin-top: 10px;border-radius: 100%;border-color: black;height:500px;width:300px" src="img2.jpg" class="card-img-top" >
    <form method="post">
        <table style="margin-left:600px;margin-top:50px">
            <tr>
                <td><input type="submit" name="s12" value="ADD"></td>
            </tr>
            <tr>
            <td><input type="submit" name="s13" value="REMOVE"></td>
            </tr>
        </table>
    </form>
    <?php
if(isset($_SESSON['s12']))
{
    $con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
    $a=$SESSION['s12']++ * 8;
    echo "$a";
}


    ?>
    </body>
</html>