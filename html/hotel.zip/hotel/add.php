<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="newadmin.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
</head>
<body>
    <div class="head">
        <h1>ADMIN</h1>
    </div>

    <div class="menu">
        <a href="admin.php"><i class="fa-solid fa-house"></i> Dashboard</a>
        <a href="add.php"><i class="fa-solid fa-plus"></i> Addnew</a>
        <a href="userad.php"><i class="fa-solid fa-users"></i>User Details</a>
        <a href="contad.php"><i class="fa-solid fa-gear"></i> CONTACTUS</a>
    </div>

<body>
    <div class="add" style="margin-top: -500px;margin-left: 600px;">
    <form  method="post" enctype="multipart/form-data">
     <table>
        
        <tr>
        <td><h1 style="margin-left: -450px;margin-top: 100px;">IMAGE</h1></td>
        <td><h1 style="margin-left: -60px;margin-top: 100px;">ITEM NAME</h1></td>
        <td><h1 style="margin-left: 50px;margin-top: 100px;">PRICE</h1></td>
        <td><h1 style="margin-left: 50px;margin-top: 100px;">ID</h1></td>
        </tr></table>
        <input style="border-radius: 20px;width: 200px;height: 30px;margin-left: -280px;margin-top: 50px;" type="file" name="t1">
             <input style="border-radius: 20px;width: 200px;height: 30px;margin-left: 20px;margin-top: 50px;" type="text" name="t2">
             <input style="border-radius: 20px;width: 200px;height: 30px;margin-left: 20px;margin-top: 50px;" type="number" name="t3" min="0">
             <input style="border-radius: 20px;width: 200px;height: 30px;margin-left: 20px;margin-top: 50px;" type="text" name="t4">
             <input class="form-control" style="background-color: #29f700;border-radius: 10%;border-color: rgb(255, 254, 254);border-width: 2px;" type="submit" name="s1" value="ADD">
             <input class="form-control" style="background-color: #29f700;border-radius: 10%;border-color: rgb(255, 254, 254);border-width: 2px;" type="submit" name="s2" value="EDIT">
             <input class="form-control" style="background-color: #29f700;border-radius: 10%;border-color: rgb(255, 254, 254);border-width: 2px;" type="submit" name="s3" value="DELETE">
</form>
            </div>
            
<?php
if(isset($_POST['s1']))
{
    $image=$_FILES['t1']['name'];
    $name=$_POST['t2'];
    $price=$_POST['t3'];
    $id=0;
    $con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
$d="insert into dish values('$id','$image','$name','$price')";
if($con->query($d))
{
    echo "<script>alert('add done')</script>";
}
else
{
    echo "<script>alert('add failed')</script>";
}
}
if(isset($_POST['s2']))
{
    $image=$_FILES['t1']['name'];
    $name=$_POST['t2'];
    $price=$_POST['t3'];
    $id=0;
    $a=$_POST['t4'];
    $con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
$d="update dish set image='$image',item='$name',price='$price' where id='$a'";
if($con->query($d))
{
    echo "<script>alert('update done')</script>";
}
else
{
    echo "<script>alert('update failed')</script>";
}
}
if(isset($_POST['s3']))
{
    $image=$_FILES['t1']['name'];
    $name=$_POST['t2'];
    $price=$_POST['t3'];
    $id=0;
    $a=$_POST['t4'];
    $con=mysqli_connect("localhost","root","","hotel");
if($con->connect_error)
{
echo"failed to connect";
}
$d="delete from dish  where id='$a'";
if($con->query($d))
{
    echo "<script>alert('update done')</script>";
}
else
{
    echo "<script>alert('update failed')</script>";
}
}

?>


</body>

</html>