<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>NS CANTEEN</title>
    <link rel="stylesheet" href="hotel.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        
</head>
<body>
    


    <!---navbar-->

    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
          <h1 style="color: #29f700;">NS CANTEEN</h1><font style="font-size: 30px;color: white;margin-right: 100px;font-family:sans-serif;">Welcome to  NS CANTEEN</font>
          </div>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mx-auto">
              <li class="nav-item">
                <a class="nav-link" href="hotel.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#about">About</a>
              </li>
             
              <li class="nav-item">
                <a class="nav-link" href="#contact">Contact</a>
              </li>
             </ul>
        
          </div>
    </nav>
        
        <?php
        $con=mysqli_connect("localhost","root","","hotel");
        if(!$con)
        {
            echo "not connected";
        }
        $q="SELECT * FROM dish";
        $view=$con->query($q);
        while($value=mysqli_fetch_array($view))
        {
            ?>
            
                <div class="ca" style="display:inline-flex; margin-left: 20px;" >
                <form method="post" >
                    <div class="card">          
                    <img style="width=200px;height200px;radius=50%;" src="<?php echo $value['image'];?>"  class="img-fluid">
                    <?php echo $value['item'];?><br>
                    <?php echo "PRICE:".$value['price'];?><br>                    
                    <!-- <input type="text" style="display: none" name="t10" value=""> -->
                    <input type="number"  name="quantity" placeholder="Quantity" min=0>
                    <button type="submit" name="addto" >Add to Cart</button>
                  
                  </div>
                  </form>
                </div>
                <?php $sno = $value['sno'];?>
      <?php  } ?>

      <?php 
    if(isset($_POST['addto']))
                  
    {
        $quan=$_POST['quantity'];
        
        $connect=mysqli_connect("localhost","root","","hotel");
        $q="select item,price from dish where sno='".$sno ."'";
        $m=$connect->query($q);
        foreach($m as $view)
        {
            $name=$view['item'];
            $price=$view['price'];
        }
        if($quan==0)
        {
            echo "<script>alert('Sorry! Out Of Stock')</script>";
        }
        else{
        $tprice=$quan*$price;
        $r="insert into addto values('$sno','$name','$price','$quan','$tprice')";
        $connect->query($r);
        }
        

        // if($connect->query($r))
        // echo "<script>alert('Successfully added to the cart')</script>";
        // else
        // echo "<script>alert('Please Try Again!')</script>";
    }

    ?><br>
      <center><a href="proview.php" class="buy"><i class="fa-regular fa-eye"></i> View Cart</a>
                      
    </body>
    </html>