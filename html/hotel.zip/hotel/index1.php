  <?php
   $connection = mysqli_connect("localhost","root","");
    $db = mysqli_select_db($connection,"hotel");

    if(isset($_POST['submit']))
        {
          $bookname = $_POST['bookname'];
          $prize = $_POST['prize'];
         $qty = $_POST['qty'];
         $image=$_FILES['image'];
         print_r ($_FILES['image']);
         $img_loc=$_FILES['image']['tmp_name'];
         $img_name=$_FILES['image']['name'];
         $img_des="uploadImage/".$img_name;
         move_uploaded_file($img_loc,'uploadImage/'.$img_name);

           $sql = "insert into 'book'(bookname,prize,qty,image)values(' $bookname',' $prize',' $qty','$img_des')";

           if(mysqli_query($connection,$sql))
           {
            header("location:index1.php");
               
           }
           else
           {
            echo "something error...";
           }
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>addbook</title>
</head>
<body>
<div class="container">
            <div class="row">
                 <div class="col-md-9">
                    <div class="card">
                    <div class="card-header">
                    <form action="index1.php" method="post" enctype="multipart/from-data">    
                        <h1>ADD BOOK</h1>
                    </div>
                    <div class="card-body">
                   
                    <button class="btn btn-success"> <a href="addbook.php" 
                    class="text-light"> Add New </a> </button>
                        
                        <br/>
                        <br/>

                    <table class="table">
                        <thead>
                            <tr>
                            <th scope="col">id</th>
                            <th scope="col">bookname</th>
                            <th scope="col">prize</th>
                            <th scope="col">qty</th>
                            <th scope="col">image</th>
                            <th scope="col">Option</th>
                            </tr>
                        </thead>
                        <body>
                                <?php
                    
                                $connection = mysqli_connect("localhost","root","","hotel");
                                $db = mysqli_select_db($connection,"book");

                                $sql = "select * from book";
                                $run = mysqli_query($connection, $sql);
                                $id= 1;
                                while($row = mysqli_fetch_array($run))
                                {
                                    $id = $row['id'];
                                    $bookname = $row['bookname'];
                                    $prize = $row['prize'];
                                    $qty = $row['qty'];
                                    $img_des=$row['image'];
                                ?>

                                   <tr>
                                        <td><?php echo $id ?></td>
                                        <td><?php echo $bookname ?></td>
                                        <td><?php echo $prize ?></td>
                                        <td><?php echo $qty ?></td>
                                        <td><img src='$row[image]' width='200px height=70px'></td>

                                        <td>
                                        <button class="btn btn-success"> <a href='edit.php?edit=<?php 
                                        echo $id ?>' class="text-light"> Edit </a> </button> &nbsp;
                                       <button class="btn btn-danger"><a href='delete.php?del=<?php
                                        echo $id ?>' class="text-light"> Delete </a> </button>
                                        </td>
                                   </tr>
                                    <?php
                                     $id++;
                                 }
                                  ?>
                        </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
</body>
</html>